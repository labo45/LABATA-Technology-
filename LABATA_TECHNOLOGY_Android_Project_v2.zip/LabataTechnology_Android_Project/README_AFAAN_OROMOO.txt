LABATA TECHNOLOGY - Android Project Starter

Kun Android Studio keessatti APK/AAB ijaaruuf project starter dha; APK dursee compiled ta'e miti.

1. Android Studio install gochuun project folder 'LabataTechnology_Android_Project' Open taasis.
2. Gradle sync xumuri.
3. Build > Build APKs (APK) ykn Build > Generate Signed Bundle/APK menu filadhu.
4. APK ijaarame output folder keessaa argachuu dandeessa.

App HTML/PWA assets keessaa WebView keessatti banama. TV Live/FM Live keessatti stream URLs amma hin guutamne.
