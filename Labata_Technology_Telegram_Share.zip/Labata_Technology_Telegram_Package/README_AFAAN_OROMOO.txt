LABATA TECHNOLOGY — TELEGRAM SHARE PACKAGE

Faayilli kun app/web app Labata Technology dha. APK (Android install file) miti.

Namoota Telegram irratti qooduuf:
1. ZIP kana Telegram irratti ergi.
2. Namni fudhate ZIP extract (unzip) haa godhu.
3. index.html Chrome keessatti banuun website/app fayyadamuun ni danda'ama.

Install akka app/PWA ta'uuf:
- Faayilota website kana hosting (HTTPS) irratti ol kaa'uun barbaachisa.
- Link hosting irraa Chrome Android keessatti banii.
- Menu (⋮) > Install app ykn Add to Home screen filadhu.

APK dhugaa (Android package) uumuuf Android build tools/SDK fi signing barbaachisu; ZIP kana keessaa APK hin jiru.
